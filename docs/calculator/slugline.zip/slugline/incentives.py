"""What shooting in Spain gives back: the film tax incentives, estimated from a budget.

A production that shoots in Spain gets part of what it spends back as a tax
deduction: 30% of the first million and 25% of the rest under the state rules,
more in Canarias and Navarra. This works out, for a budget made by `budget`,
how much each territory's regime would return, and why (the base, the rate,
which limit bit).

It is an estimate and says so: the real base is what an auditor certifies, and
each regime has requirements (certificates, registration, minimum shooting) a
budget can't check. The rules are data, in `incentive_rules.py`, each with its
source and the date it was checked.
"""

from __future__ import annotations

from slugline.incentive_rules import PENDING, RULES

KINDS = ("spanish", "foreign")
WARNING = ("Estimación orientativa a partir del presupuesto, no asesoramiento fiscal. La base real la certifica "
           "un auditor y cada régimen tiene requisitos (certificados, registro, gasto mínimo) que conviene "
           "confirmar con un asesor y con la film commission.")


def checked() -> str:
    """The date of the oldest check among the rules: how fresh the estimate is."""
    return min(rule["checked"] for rule in RULES)


def eligible_base(result: dict, kind: str) -> float:
    """A first guess at the deduction base, from a budget (`budget.compute`).

    The producer's own production (`spanish`): the production cost, without the
    contingency, which isn't a cost until it's spent. A foreign production
    (`foreign`): only what is spent in Spain on crew, cast and suppliers, so also
    without the script and rights, overheads, and publicity and finance.
    """
    lines = [line for chapter in result["chapters"] for line in chapter["lines"]]
    if kind == "spanish":
        return round(sum(line["total"] for line in lines), 2)
    left_out = {"script"}
    return round(sum(line["total"] for line in lines
                     if line["key"] not in left_out and line["chapter"] not in ("11", "12")), 2)


def _tiered(base: float, tiers: list) -> float:
    amount, floor = 0.0, 0.0
    for ceiling, rate in tiers:
        top = base if ceiling is None else min(base, ceiling)
        if top > floor:
            amount += (top - floor) * rate
        if ceiling is None or base <= ceiling:
            break
        floor = ceiling
    return amount


def apply(rule: dict, *, base: float, cost: float, local: float = 1.0, short: bool = False,
          animation: bool = False, special: bool = False, episodes: int = 0, other_aid: float = 0) -> dict:
    """One regime on one production. `base` is the eligible base, `cost` the
    production cost, `local` the share of the base spent in the territory."""
    spend = base * local
    notes: list[str] = []
    out = {"key": rule["key"], "where": rule["where"], "kind": rule["kind"], "law": rule["law"],
           "needs": rule["needs"], "source": rule["source"], "checked": rule["checked"],
           "amount": 0, "base": 0, "rate": 0.0, "limited_by": "", "notes": notes}
    if rule.get("note"):
        notes.append(rule["note"])

    minimum = rule.get("min_spend_animation" if animation else "min_spend")
    if minimum and spend < minimum:
        out["limited_by"] = "min_spend"
        notes.append(f"Hace falta gastar al menos {minimum:,.0f} € en {rule['where']}.".replace(",", "."))
        return out

    if rule["kind"] == "foreign":
        deduction_base = spend  # only what is spent in the territory counts
    else:
        need = rule.get("local_share", 0)
        if local >= need:
            deduction_base = base
        elif rule["where"] == "Navarra":  # below 40%, the base is the local spend / 0.4
            deduction_base = spend / need
            notes.append(f"Se gasta menos del {need:.0%} en Navarra: la base se reduce al gasto local / {need}.")
        else:
            out["limited_by"] = "local_share"
            notes.append(f"Al menos el {need:.0%} de la base tiene que gastarse en España.")
            return out
    if rule.get("base_cap"):
        deduction_base = min(deduction_base, cost * rule["base_cap"])

    tiers = rule["tiers_special"] if special and rule.get("tiers_special") else rule["tiers"]
    amount = _tiered(deduction_base, tiers)

    cap = rule["cap_episode"] * episodes if episodes and rule.get("cap_episode") else rule["cap"]
    if amount > cap:
        amount, out["limited_by"] = cap, "cap"
    pct = rule["aid_limit_short"] if short and rule.get("aid_limit_short") else rule["aid_limit"]
    room = max(0.0, cost * pct - other_aid)
    if amount > room:
        amount, out["limited_by"] = room, "aid_limit"
        notes.append(f"La deducción y las demás ayudas no pueden pasar del {pct:.0%} del coste.")

    out.update(amount=round(amount), base=round(deduction_base), rate=round(amount / deduction_base, 4)
               if deduction_base else 0.0)
    return out


def estimate(result: dict, kind: str = "spanish", *, base: float | None = None, local: float = 1.0,
             short: bool | None = None, animation: bool = False, special: bool = False, episodes: int = 0,
             other_aid: float = 0) -> dict:
    """What each territory would give back for this budget, best first.

    `base` overrides the eligible base worked out from the budget; `local` is
    the share of it spent in the territory where you'd shoot.
    """
    if kind not in KINDS:
        raise ValueError(f"unknown kind: {kind}")
    if result.get("currency", "EUR") != "EUR":
        raise ValueError("the Spanish incentives apply to a budget at Spanish rates, in euros")
    cost = eligible_base(result, "spanish")
    guess = eligible_base(result, kind)
    base = guess if base is None else max(0.0, float(base))
    cost = max(cost, base)  # an edited base bigger than this budget means a bigger production
    if short is None:
        short = result.get("level") == "short"
    options = [apply(rule, base=base, cost=cost, local=local, short=short, animation=animation, special=special,
                     episodes=episodes, other_aid=other_aid)
               for rule in RULES if rule["kind"] == kind]
    options.sort(key=lambda o: -o["amount"])
    return {
        "kind": kind, "currency": result.get("currency", "EUR"), "cost": round(cost), "base": round(base),
        "base_guess": round(guess), "options": options, "best": options[0] if options else None,
        "pending": PENDING, "checked": checked(), "warning": WARNING,
    }
