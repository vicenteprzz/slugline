"""The film tax incentives Slugline estimates, as data: one entry per regime.

Only figures read in the law or in an official source are here, each with that
source and the date it was checked. To update a rule, change its numbers, its
`source` and its `checked` date; `incentives.py` doesn't need touching.
Regimes that haven't been verified yet are listed in PENDING, not guessed.

Fields:
  where, kind      the territory and "spanish" (the producer's own production)
                   or "foreign" (a Spanish service company shooting a foreign one)
  tiers            [(up to this much base, rate), ...]: the last one has no ceiling
  cap              maximum deduction per production; cap_episode for series
  min_spend        minimum spend in the territory (min_spend_animation for animation)
  local_share      the part of the base that has to be spent in the territory; below
                   it, the base shrinks to spend / local_share
  base_cap         the base can't be more than this share of the total cost
  aid_limit        deduction + other public aid <= this share of the production cost;
                   aid_limit_short for short films
"""

RULES = [
    {
        "key": "spain_spanish",
        "where": "Spain", "kind": "spanish",
        "law": "Art. 36.1 Ley 27/2014 del Impuesto sobre Sociedades",
        "tiers": [(1_000_000, 0.30), (None, 0.25)],
        "cap": 20_000_000, "cap_episode": 10_000_000,
        "local_share": 0.5,  # at least 50% of the base spent in Spain
        "aid_limit": 0.50, "aid_limit_short": 0.85,
        "needs": "Certificado de nacionalidad y certificado cultural del ICAA o de la comunidad autónoma; "
                 "copia depositada en la Filmoteca.",
        "source": "https://www.boe.es/buscar/act.php?id=BOE-A-2014-12328 (art. 36.1, redacción de la Ley 38/2022)",
        "checked": "2026-11-25",
    },
    {
        "key": "spain_foreign",
        "where": "Spain", "kind": "foreign",
        "law": "Art. 36.2 Ley 27/2014 del Impuesto sobre Sociedades",
        "tiers": [(1_000_000, 0.30), (None, 0.25)],
        "cap": 20_000_000, "cap_episode": 10_000_000,
        "min_spend": 1_000_000, "min_spend_animation": 200_000,
        "aid_limit": 0.50,
        "needs": "La deduce la productora española inscrita en el registro del ICAA que ejecuta el rodaje; "
                 "certificado cultural. Base: gasto en España en personal creativo (residente en la UE/EEE) "
                 "e industrias técnicas y proveedores.",
        "note": "Por debajo de 1 M€ de gasto, solo los servicios de efectos visuales: 30 % con el límite de minimis.",
        "source": "https://www.boe.es/buscar/act.php?id=BOE-A-2014-12328 (art. 36.2, redacción de la Ley 38/2022)",
        "checked": "2026-11-25",
    },
    {
        "key": "canarias_spanish",
        "where": "Canarias", "kind": "spanish",
        "law": "Art. 36.1 LIS con los porcentajes incrementados del art. 94 de la Ley 20/1991 (REF de Canarias)",
        "tiers": [(1_000_000, 0.54), (None, 0.45)],
        "cap": 36_000_000, "cap_episode": 18_000_000,
        "local_share": 0.5,
        "aid_limit": 0.50, "aid_limit_short": 0.85,
        "needs": "Gasto realizado en Canarias; los mismos certificados que en el resto de España.",
        "source": "Agencia Tributaria, Manual de Sociedades 2024, cap. 12 (régimen fiscal de Canarias)",
        "checked": "2026-11-25",
    },
    {
        "key": "canarias_foreign",
        "where": "Canarias", "kind": "foreign",
        "law": "Art. 36.2 LIS con los porcentajes incrementados del art. 94 de la Ley 20/1991 (REF de Canarias)",
        "tiers": [(1_000_000, 0.54), (None, 0.45)],
        "cap": 36_000_000, "cap_episode": 18_000_000,
        "min_spend": 1_000_000, "min_spend_animation": 200_000,
        "aid_limit": 0.50,
        "needs": "Gasto realizado en Canarias, por una productora inscrita en el registro del ICAA.",
        "source": "Agencia Tributaria, Manual de Sociedades 2024, cap. 12: deducción por inversiones en "
                  "producciones cinematográficas extranjeras en Canarias",
        "checked": "2026-11-25",
    },
    {
        "key": "navarra_spanish",
        "where": "Navarra", "kind": "spanish",
        "law": "Art. 65.1 Ley Foral 26/2016 del Impuesto sobre Sociedades de Navarra",
        "tiers": [(None, 0.45)],
        # 50% on the first 3 M€ for shorts, animation, documentaries, first films,
        # films directed only by women and films whose only original version is in Basque.
        "tiers_special": [(3_000_000, 0.50), (None, 0.45)],
        "cap": 5_000_000,
        "local_share": 0.4,  # Navarra spend >= 40% of the investment, else base = spend / 0.4
        "base_cap": 0.8,
        "aid_limit": 0.50, "aid_limit_short": 0.85,
        "needs": "Productora con domicilio fiscal en Navarra; reconocimiento de la inversión por la Dirección "
                 "General de Cultura (Orden Foral 69/2021).",
        "source": "Gobierno de Navarra, «Deducción en el impuesto de sociedades por inversiones en películas», "
                  "guía de enero de 2026 (LF 26/2016 con la LF 17/2025)",
        "checked": "2026-11-25",
    },
    {
        "key": "navarra_foreign",
        "where": "Navarra", "kind": "foreign",
        "law": "Art. 65.2 Ley Foral 26/2016 del Impuesto sobre Sociedades de Navarra",
        "tiers": [(None, 0.35)],
        "cap": 5_000_000,
        "aid_limit": 0.50,
        "needs": "Base: gasto en Navarra en personal creativo (hasta 50.000 € por persona) e industrias técnicas, "
                 "transporte, alojamiento y manutención; certificado cultural.",
        "source": "Gobierno de Navarra, «Deducción en el impuesto de sociedades por inversiones en películas», "
                  "guía de enero de 2026 (LF 26/2016 con la LF 17/2025)",
        "checked": "2026-11-25",
    },
]

# Not estimated until checked against the law itself.
PENDING = [
    "País Vasco (Álava, Bizkaia y Gipuzkoa): cada territorio tiene su norma foral, con porcentajes que las guías "
    "dan de forma contradictoria.",
]
