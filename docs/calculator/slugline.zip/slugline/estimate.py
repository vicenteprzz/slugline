"""What would it cost to shoot this script? A quick estimate from the script alone.

This is the free calculator on the website. It runs in the visitor's browser
(Pyodide), so the script never leaves their computer, and it uses the same
parser, breakdown, keyword elements and budget as the app: only the inputs a
person would add in the app (a hand-made schedule, edited elements, their own
rates) are missing, so every figure here is a starting point.

`estimate` only uses the standard library and the modules listed in
`MODULES`; `tools/build_calculator.py` packs exactly those for the website.
"""

from __future__ import annotations

from slugline import budget
from slugline.breakdown import breakdown
from slugline.elements import CATEGORY_KEYS, ElementSheet, totals
from slugline.keywords import suggest
from slugline.parser import format_eighths, parse

# The modules the calculator needs in the browser (see tools/build_calculator.py).
MODULES = [
    "__init__", "parser", "breakdown", "lint", "revisions", "schedule", "elements", "keywords",
    "catalan", "constraints", "budget", "fdx_import", "pdf_import", "estimate",
]

# Where the money is counted: the budget prices each country with its own
# rates and currency (American rates in dollars, Spanish ones in euros).
MARKETS = {"us": {"country": "us"}, "eu": {"country": "es"}}
TIERS = ["short", "low", "medium", "high"]
SHORT_PAGES = 45  # below this, a script reads as a short; it's only priced as one


def _round(amount: float) -> int:
    """Two significant figures: an estimate shouldn't look more exact than it is."""
    if amount <= 0:
        return 0
    digits = len(str(int(amount))) - 2
    step = 10 ** max(digits, 0)
    return int(round(amount / step) * step)


def estimate(text: str, market: str = "us") -> dict:
    """The script in figures, and what it would cost to shoot: at four sizes of
    production for a feature, and as a short for a short."""
    if market not in MARKETS:
        raise ValueError(f"unknown market: {market}")
    m = MARKETS[market]
    play = parse(text)
    b = breakdown(play)
    if not b.scenes:
        raise ValueError("no scenes found: is this a screenplay?")
    sheet = ElementSheet(scenes=suggest(play))
    found = totals(sheet, b)

    pages = round(b.page_count, 1)
    fit = "short" if pages < SHORT_PAGES else "low"
    tiers = []
    # A short is priced as a short: feature crews, rates and lump sums on a
    # 30-page script give figures nobody would believe.
    for level in (["short"] if fit == "short" else TIERS):
        result = budget.compute(b, None, sheet, budget.BudgetSettings(level=level, country=m["country"]))
        tier = {
            "level": level,
            "days": result["days"],
            "total": _round(result["total"]),
            "per_day": _round(result["total"] / result["days"]) if result["days"] else 0,
            "to_quote": result["to_quote"]["count"],
        }
        if level == fit:
            tier["chapters"] = [
                {"code": c["code"], "label": c["label"], "total": _round(c["total"])}
                for c in result["chapters"] if c["total"] > 0
            ]
            rows = {s.number: s for s in b.scenes}
            tier["costly_scenes"] = [
                {"number": s["number"], "heading": s["heading"], "length": format_eighths(rows[s["number"]].eighths),
                 "cost": _round(s["cost"])}
                for s in result["scenes"][:3]
            ]
        tiers.append(tier)

    def count(category: str) -> dict:
        items = [t for t in found if t.category == category]
        scenes = {n for t in items for n in t.scenes}
        return {"items": [t.name for t in items[:4]], "scenes": len(scenes)}

    nights = b.day_night.get("NIGHT", 0)
    return {
        "title": b.title or "",
        "market": market,
        "currency": budget.market(m["country"])[0],
        "pages": pages,
        "scenes": b.scene_count,
        "speaking": len(b.characters),
        "cast": [{"name": c.name, "scenes": len(c.scenes)} for c in b.characters[:6]],
        "locations": len(b.locations),
        "top_locations": [{"name": loc.location, "scenes": len(loc.scenes), "length": format_eighths(loc.eighths)}
                          for loc in b.locations[:5]],
        "int_ext": b.int_ext,
        "day_night": b.day_night,
        "night_share": round(nights / b.scene_count, 2) if b.scene_count else 0,
        "elements": {key: count(key) for key in CATEGORY_KEYS
                     if key in ("extras", "stunts", "vehicles", "animals", "sfx", "vfx")},
        "fit": fit,
        "tiers": tiers,
    }
